sudo iptables -I INPUT 1 -p tcp --dport 9292 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 5000 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 80 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 5672 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 6080 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 8774 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 8775 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 8778 -j ACCEPT 
sudo iptables -I INPUT 1 -p tcp --dport 4369 -j ACCEPT
sudo iptables -I INPUT 1 -p tcp --dport 25672 -j ACCEPT
sudo iptables -I INPUT 1 -p tcp --dport 9696 -j ACCEPT
sudo iptables -I INPUT 1 -p tcp --dport 35357 -j ACCEPT
sudo iptables -I INPUT 1 -p tcp --dport 11211 -j ACCEPT
sudo iptables -I INPUT 1 -p tcp --dport 8776 -j ACCEPT
sleep 60 && sudo systemctl restart rabbitmq-server

